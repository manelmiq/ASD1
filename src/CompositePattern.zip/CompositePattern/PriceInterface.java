package CompositePattern;

public interface PriceInterface {
    public double netPrice();

    public double discountPrice();

    public double computePrice();


}

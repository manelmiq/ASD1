package ObserverPattern.part1;


public interface Observer {

    void update(int counter);

}


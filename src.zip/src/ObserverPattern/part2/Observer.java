package ObserverPattern.part2;


public interface Observer {

    void update(int counter);

}


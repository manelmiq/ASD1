package ObserverPattern.part2;


public class AbstractFrame extends javax.swing.JFrame {

    public SimpleCounter count;

}
